function [ out ] = vec( in )
% vectorize input: out = in(:)
out = in(:);

end

