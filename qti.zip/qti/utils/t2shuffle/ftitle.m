function ftitle( title_str, fontsize )

if nargin < 2
    fontsize = 16;
end

title(title_str, 'fontsize', fontsize);
end

