function minmax(ob)

minmax(struct(ob))
