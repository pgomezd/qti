function beeper(n)
% make beeping noise to alert that a job is done.

for ii=1:n
	beep
	pause(0.2)
end
